function cargarContenidoComun()
{
	$("header").load("html/header.html");
	$("footer").load("html/footer.html");
	$("#contenido").css({display:"none"}).fadeIn("slow");
}