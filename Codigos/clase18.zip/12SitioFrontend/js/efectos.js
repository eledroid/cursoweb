function cargarContenidoComun()
{
	$("header").load("html/header.html");
	$("footer").load("html/footer.html");
	$("#contenido").css({display:"none"}).fadeIn("slow");
	$("header").before("<input type='checkbox' id='menu-movil' /><label for='menu-movil'></label>");
}
