/*
Analisis e implementación de componentes.
Análisis:
	1) Ver el funcionamiento del componente.
	2) Analizar el código html y js que lo hace funcionar.
	3) Ver que archivos necesito. (js, css, img, etc).
	4) LEER y REVISAR la DOCUMENTACIÓN del componente, NO SEAN FLOJOS y quieran todo peladito y a la boca (FÁCIL).
	5) Revisar los atributos y métodos que tenga el componente para sacarle el máximo provecho. 

Implementación:
	1) Nunca te adaptes a la estructura de la carpeta demo del componente, ADAPTA el componente a la carpeta de tu proyecto (LIKE A FUCKIN' BOSS).
	2) Copia los archivos necesarios a la estructura de tu carpetas (css, js, img, etc).
	3) Si el componente usa imágenes, busca sus url en el css del componente y reemplázalas por la nueva ruta que tendrán.
	4) En el css del componente nunca trates de cambiar atributos css, puedes hacer que el componente deje de funcionar correctamente, si acaso modifica valores de colores para que el componente se adapte a la paleta de colores de tu proyecto.
	5) Revisa los atributos y css que necesitan tus elementos html para que el componente funcione.
	6) Revisa la programación jQuery que hace funcionar el componente.
*/
function ejemplosFancybox()
{
	$(".galeria-sencilla").fancybox();

	$("#efecto1").fancybox({
		openEffect:"elastic",
		openSpeed:2000,
		closeEffect:"elastic"
	});

	$("#efecto2").fancybox({
		closeEffect:"elastic",
		closeSpeed:1500,
		helpers:{
			title:{
				type:"inside",
				position:"top"
			}
		}
	});

	$("#efecto3").fancybox({
		helpers:{
			title:{
				type:"outside",
				position:"top"
			},
			overlay:{
				css:{
					"background":"rgba(255,102,0,.5)"
				},
				closeClick:false
			}
		}
	});

	$("#efecto4").fancybox({
		openEffect:"none",
		openSpeed:5000,
		helpers:{
			title:{
				type:"over"
			}
		}
	});

	$("#efecto5").fancybox({
		closeEffect:"none",
		helpers:{
			title:{
				position:"top"
			}
		}
	});

	$("#error").fancybox();

	$("#mostrar-oculto").fancybox();

	$("#mostrar-por-ajax").fancybox();

	$("#mostrar-en-iframe").fancybox();

	$("#mostrar-swf").fancybox();

	$(".social-media").fancybox({
		helpers:{
			media:true
		}
	});
}

$(document).on("ready",ejemplosFancybox);