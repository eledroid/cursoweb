//carga de contenido común función que se ejecuta en todas mis secciones
function cargarContenidoComun()
{
	$("header").load("html/header.html");
	$("footer").load("html/footer.html");
	$("#contenido").css({display:"none"}).fadeIn("slow");
	$("header").before("<input type='checkbox' id='menu-movil' /><label for='menu-movil'></label>");
}

//código para index.html
function iniciarSlider()
{
	cargarContenidoComun();

	$("#slider").flexslider({
		animation:"slide",
		/*direction:"vertical",*/
		controlNav:false
	});

	if($(window).width()<=600)
	{
		$("#social-media").remove();
	}
}