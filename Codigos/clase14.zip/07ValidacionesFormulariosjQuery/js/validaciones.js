//apprise("Probando JavaScript");
function validarForm()
{
	var verificar=true;
	var expRegNombre=/^[a-zA-ZÑñÁáÉéÍíÓóÚúÜü\s]+$/;
	var expRegEmail=/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/;
	var expRegFecha=/^[0-9][0-9][0-9][0-9]\-[0-9][0-9]\-[0-9][0-9]$/;
	var formulario = document.getElementById("contacto-frm");
	var nombre = document.getElementById("nombre");
	var edad = document.getElementById("edad");
	var email = document.getElementById("email");
	var clave = document.getElementById("clave");
	var clave2 = document.getElementById("clave2");
	var masculino = document.getElementById("M");
	var femenino = document.getElementById("F");
	var nacimiento = document.getElementById("nacimiento");
	var region = document.getElementById("region");
	var archivo = document.getElementById("archivo");
	var twitterChk = document.contacto_frm.twitter_chk;
	var twitter = document.getElementById("twitter");
	var facebookChk = document.contacto_frm.facebook_chk;
	var facebook = document.getElementById("facebook");
	var youtubeChk = document.contacto_frm.youtube_chk;
	var youtube = document.getElementById("youtube");
	var comentarios = document.getElementById("comentarios");
	var condiciones = document.getElementById("condiciones");

	if(!nombre.value)
	{
		apprise("El campo nombre es requerido",{animate:false},function(){
			nombre.focus();
		});
		verificar = false;
	}
	else if(!expRegNombre.exec(nombre.value))
	{
		apprise("El campo nombre sólo acepta Letras y espacios en blanco",{
			animate:true,
			"textOk":"Aceptar"
		},function(){
			nombre.focus();
		});
		verificar = false;
	}
	else if(!edad.value)
	{
		apprise("El campo edad es requerido");
		edad.focus();
		verificar = false;
	}
	else if(isNaN(edad.value))//is Not a Number
	{
		apprise("El campo edad solo acepta números");
		edad.focus();
		verificar = false;
	}
	else if(edad.value.length > 2)
	{
		apprise("El campo edad sólo acepta 2 dígitos");
		edad.focus();
		verificar = false;
	}
	else if(edad.value < 18 || edad.value > 60)
	{
		apprise("Debes estar en un rango de edad entre 18 y 60 años");
		edad.focus();
		verificar = false;
	}
	else if(!email.value)
	{
		apprise("El campo email es requerido");
		email.focus();
		verificar = false;
	}
	else if(!expRegEmail.exec(email.value))
	{
		apprise("El campo email no es valido");
		email.focus();
		verificar = false;
	}
	else if(!clave.value)
	{
		apprise("El campo clave es requerido");
		clave.focus();
		verificar = false;
	}
	else if(clave.value.length < 6)
	{
		apprise("La clave debe de tener 6 caracteres mínimo");
		clave.focus();
		verificar = false;
	}
	else if(clave2.value!=clave.value)
	{
		apprise("La clave no coincide con su confirmación");
		clave2.focus();
		verificar = false;
	}
	else if(!masculino.checked && !femenino.checked)
	{
		apprise("El campo sexo es requerido");
		femenino.focus();
		verificar = false;
	}
	else if(!nacimiento.value || nacimiento.value=="aaaa-mm-dd")
	{
		apprise("El campo nacimiento es requerido");
		nacimiento.focus();
		verificar =  false;
	}
	else if(!expRegFecha.exec(nacimiento.value))
	{
		apprise("La fecha de nacimiento no es válida");
		nacimiento.focus();
		verificar = false;
	}
	else if(!region.value)
	{
		apprise("El campo región es requerido");
		region.focus();
		verificar = false;
	}
	else if(!archivo.value)
	{
		apprise("El campo archivo es requerido");
		archivo.focus();
		verificar = false;
	}
	else if(twitterChk.checked && !twitter.value)
	{
		apprise("Proporciona tu twitter");
		twitter.focus();
		verificar = false;
	}
	else if(facebookChk.checked && !facebook.value)
	{
		apprise("Proporciona tu facebook");
		facebook.focus();
		verificar = false;
	}
	else if(youtubeChk.checked && !youtube.value)
	{
		apprise("Proporciona tu youtube");
		youtube.focus();
		verificar = false;
	}
	else if(!comentarios.value)
	{
		apprise("El campo comentarios es requerido");
		comentarios.focus();
		verificar = false;
	}
	else if(comentarios.value.length > 255)
	{
		apprise("El campo comentarios no puede tener más de 255 caracteres");
		comentarios.focus();
		verificar = false;
	}
	else if(!condiciones.checked)
	{
		apprise("Tienes que aceptar los términos y condiciones");
		condiciones.focus();
		verificar = false;
	}


	if(verificar)
	{
		//apprise("Validando formulario de manera sucia iuck");
		apprise("Validando formulario de forma cool");
		//formulario.submit();
	}
}

function limpiarForm()
{
	//apprise("Limpiando formulario de manera sucia iuck");
	apprise("Limpiando formulario de forma cool");
	document.getElementById("contacto-frm").reset();
}

function habilitar(evento)
{
	//apprise(evento.target.name);
	var caja;
	switch(evento.target.name)
	{
		case "twitter_chk":
			caja = document.getElementById("twitter");
			break;
		case "facebook_chk":
			caja = document.getElementById("facebook");
			break;
		case "youtube_chk":
			caja = document.getElementById("youtube");
			break;
	}

	if(evento.target.checked)
	{
		caja.disabled = false;
	}
	else
	{
		caja.disabled = true;
		caja.value = "";
	}
}

function alCargarVentana()
{
	//apprise("Se ha cargado la ventana");
	var botonEnviar = document.getElementById("enviar");
	botonEnviar.onclick = validarForm;

	var botonLimpiar = document.contacto_frm.limpiar_btn;
	botonLimpiar.onclick = limpiarForm;

	var twitterCasilla = document.contacto_frm.twitter_chk;
	twitterCasilla.onclick = habilitar;

	var facebookCasilla = document.contacto_frm.facebook_chk;
	facebookCasilla.onclick = habilitar;

	var youtubeCasilla = document.contacto_frm.youtube_chk;
	youtubeCasilla.onclick = habilitar;
}

//formula para vincular eventos
//queObjeto.queEvento = queFuncion;
window.onload = alCargarVentana;