$(document).on("ready",function(){
	/*$("body").slideshow({
		fondo:"sandybrown"
	});*/
	$("#galeria").slideshow();
});

//por si algún archivo js anterior quedo mal cerrado
;

//Función anónima autoejecutable, con esto evitamos que si hay mas librerias en el documento no creen conflicto con jQuery, le estamos diciendo que creamos una función anónima que se encuentra dentro del ámbito y alcance de jQuery, esto se conoce como una extensión de la libreria jQuery
(function($){
	//Esta es la manera de crear un plugin, con jQuery.fn.extend lo que hacemos es extender a jQuery y agregar la nueva función a crear, en este caso slideshow.
	jQuery.fn.extend({
		//nombre del componente
		slideshow:function(opciones)
		{
			iniciales = {
				fondo:"#212121",
				color:"#FFF",
				sig:"#siguiente",
				ant:"#anterior"
			}

			//Con la función $.extend() mezclamos los valores iniciales del componente con los que manda el usuario, si el usuario no manda algún parámetro, el componente tomara el valor inicial.
			var opciones = $.extend({},iniciales,opciones);

			function inicializar()
			{
				//DECLARACIÓN DE LIBRERIAS
				
				//DECLARACIÓN DE VARIABLES
				//declaración de variable que tiene un objeto jQuery
				$contenedor = $(this).children().eq(0);
				var $fotos = $contenedor.children();
				var cantidad = $fotos.length;
				//outerWidth suma border, padding, margin y width del elemento
				var anchuraFoto = $fotos.outerWidth(true);
				var anchuraTotal = cantidad*anchuraFoto;
				var fotoMostrada = 1;
				var anchuraAnterior = (anchuraTotal-anchuraFoto)*-1;
				var movimientoAutomatico;

				console.log("contenedor:",$contenedor);
				console.log("fotos:",$fotos);
				console.log("cantidad:",cantidad);
				console.log("anchuraFoto:",anchuraFoto);
				console.log("anchuraTotal:",anchuraTotal);
				console.log("anchuraAnterior:",anchuraAnterior);

				//DECLARACIÓN DE FUNCIONES
				function fotoSiguiente(evento)
				{
					//alert("Siguiente");
					if(evento)
						evento.preventDefault();

					if(fotoMostrada == cantidad)
					{
						//regrasar a la primera
						fotoMostrada = 1;
						//$contenedor.animate({left:0},5000);
						$contenedor.css({
							display:"none",
							left:0
						}).fadeIn(2000);
					}
					else
					{
						//avanza una foto
						fotoMostrada++;	
						$contenedor.animate({left:"-="+anchuraFoto},"swing");
					}
					console.log("contador: ",fotoMostrada);
					mostrarTitulo();
				}

				function fotoAnterior(evento)
				{
					//alert("Anterior");
					evento.preventDefault();
					if(fotoMostrada == 1)
					{
						//ir a la ultima
						fotoMostrada = cantidad;
						//$contenedor.animate({left:anchuraAnterior},5000);
						$contenedor.css({
							display:"none",
							left:anchuraAnterior
						}).fadeIn(2000);
					}
					else
					{
						//retrocedo una foto
						fotoMostrada--;	
						$contenedor.animate({left:"+="+anchuraFoto},"swing");
					}
					console.log("contador: ",fotoMostrada);
					mostrarTitulo();
				}

				function mostrarTitulo()
				{
					$tituloImagen = $($fotos[fotoMostrada-1]).children().attr("alt");
					//$(".slideshow h1").text($tituloImagen);
					$(".slideshow").find("h1").text($tituloImagen);
					console.log($tituloImagen);
				}

				function pausarMovimiento()
				{
					clearInterval(movimientoAutomatico);
				}

				function seguirMovimiento()
				{
					movimientoAutomatico = setInterval(fotoSiguiente,3000);
				}


				//EJECUCIÓN DE EVENTOS Y ESTADOS INICIALES
				/*$(this).css({
					background:opciones.fondo,
					color:opciones.color
				});*/
				$contenedor.css({width:anchuraTotal});
				$(opciones.sig).on("click",fotoSiguiente);
				$(opciones.ant).on("click",fotoAnterior);
				mostrarTitulo();
				//Funciones de tiempo en Javascript: setTimeOut, clearTimeOut, setInterval, clearInterval
				$("#galeria, .slideshow a").hover(pausarMovimiento,seguirMovimiento);
			}

			//En cada función que extendamos tenemos que agregar un this.each, para que pueda afectar a todos los elementos que le mandemos por jQuery, por ejemplo cuando se manda una clase y más de 1 elemento la utiliza.
			return $(this).each(inicializar);
		}
	});
})(jQuery);