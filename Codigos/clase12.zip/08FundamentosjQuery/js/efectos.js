//alert("funciona");
// $() -> jQuery
// $(objeto).evento(función)
/*
$(document).ready(function(){
	alert("Esto es jQuery antes de la v1.7.1");
});
*/

//$(objeto).on/off("evento",función);
function efectos()
{
	//alert("Mamá ya se usar jQuery }=D");
	$("p").on("click",function(){
		$(this).hide();
	});

	$("#boton").on("click",function(){
		$("p").show();
	});

	$("p").css("background","yellow");

	$("#boton2").on("click",function(){
		$("p").hide(3000);
	});

	$("#boton3").on("click",function(){
		$("p").show("slow"); /*slow,fast,swing*/
	});

	$("#boton4").on("click",function(){
		$("p").toggle();
	});

	$("#boton5").on("click",function(){
		$("p").toggle("swing");
	});

	$(".mostrar").on("click",function(){
		$(".capa-deslizante").slideDown("fast");
	});

	$(".ocultar").on("click", function(){
		$(".capa-deslizante").slideUp(4000);
	});

	$(".mostrar-ocultar").on("click",function(){
		$(".capa-deslizante").slideToggle("slow");
	});

	$("#boton6").on("click",function(){
		$("#cuadro").fadeTo("fast",.25);
	});

	$("#boton7").on("click",function(){
		$("#cuadro").fadeTo(3000,1);
	});

	$("#boton8").on("click",function(){
		$("#cuadro").fadeOut(4000);
	});

	$("#boton9").on("click",function(){
		$("#cuadro").fadeIn(4000);
	});

	$("#parpadea").on("click",function(){
		$("#cuadro").fadeOut().fadeIn();
	});

	$("#boton10").on("click",function(){
		$(".capa-animable").animate({height:300},"slow");
		$(".capa-animable").animate({width:300},"fast");
		$(".capa-animable").animate({width:100,height:100},3000);
	});

	$("#boton11").on("click",function(){
		$(".capa-animable2").animate({left:"50%"},"swing");
		$(".capa-animable2").animate({width:"300px"},1500);
		$(".capa-animable2").animate({fontSize:"3em"},2000);
		$(".capa-animable2").animate({"font-size":"2em"},2500);
		$(".capa-animable2").animate({top:-100},"slow");
		$(".capa-animable2").animate({
			left:0,
			top:0,
			"font-size":"1em",
			width:100
		},5000);
	});
}

$(document).on("ready",efectos);