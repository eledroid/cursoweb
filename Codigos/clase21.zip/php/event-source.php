<?php
header("Content-Type: text/event-stream");
header("Cache-Control: no-cache");
echo "retry:1000\n";
echo "data: <p>La hora del servidor es: ".date("r")."</p>\n\n";
?>