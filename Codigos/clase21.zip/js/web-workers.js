var i=0;

function contando()
{
	i++;
	postMessage(i);
}

setInterval(contando,2000);