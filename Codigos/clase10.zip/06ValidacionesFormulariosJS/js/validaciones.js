//alert("Probando JavaScript");
function validarForm()
{
	//alert("Validando formulario de manera sucia iuck");
	alert("Validando formulario de forma cool");
	document.contacto_frm.submit();
}

function limpiarForm()
{
	//alert("Limpiando formulario de manera sucia iuck");
	alert("Limpiando formulario de forma cool");
	document.getElementById("contacto-frm").reset();
}

function alCargarVentana()
{
	//alert("Se ha cargado la ventana");
	var botonEnviar = document.getElementById("enviar");
	botonEnviar.onclick = validarForm;

	var botonLimpiar = document.contacto_frm.limpiar_btn;
	botonLimpiar.onclick = limpiarForm;
}

//formula para vincular eventos
//queObjeto.queEvento = queFuncion;
window.onload = alCargarVentana;