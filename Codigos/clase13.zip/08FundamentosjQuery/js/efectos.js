//alert("funciona");
// $() -> jQuery
// $(objeto).evento(función)
/*
$(document).ready(function(){
	alert("Esto es jQuery antes de la v1.7.1");
});
*/

//$(objeto).on/off("evento",función);
function efectos()
{
	//alert("Mamá ya se usar jQuery }=D");
	$("p").on("click",function(){
		$(this).hide();
	});

	$("#boton").on("click",function(){
		$("p").show();
	});

	$("p").css("background","yellow");

	$("#boton2").on("click",function(){
		$("p").hide(3000);
	});

	$("#boton3").on("click",function(){
		$("p").show("slow"); /*slow,fast,swing*/
	});

	$("#boton4").on("click",function(){
		$("p").toggle();
	});

	$("#boton5").on("click",function(){
		$("p").toggle("swing");
	});

	$(".mostrar").on("click",function(){
		$(".capa-deslizante").slideDown("fast");
	});

	$(".ocultar").on("click", function(){
		$(".capa-deslizante").slideUp(4000);
	});

	$(".mostrar-ocultar").on("click",function(){
		$(".capa-deslizante").slideToggle("slow");
	});

	$("#boton6").on("click",function(){
		$("#cuadro").fadeTo("fast",.25);
	});

	$("#boton7").on("click",function(){
		$("#cuadro").fadeTo(3000,1);
	});

	$("#boton8").on("click",function(){
		$("#cuadro").fadeOut(4000);
	});

	$("#boton9").on("click",function(){
		$("#cuadro").fadeIn(4000);
	});

	$("#parpadea").on("click",function(){
		$("#cuadro").fadeOut().fadeIn();
	});

	$("#boton10").on("click",function(){
		$(".capa-animable").animate({height:300},"slow");
		$(".capa-animable").animate({width:300},"fast");
		$(".capa-animable").animate({width:100,height:100},3000);
	});

	$("#boton11").on("click",function(){
		$(".capa-animable2").animate({left:"50%"},"swing");
		$(".capa-animable2").animate({width:"300px"},1500);
		$(".capa-animable2").animate({fontSize:"3em"},2000);
		$(".capa-animable2").animate({"font-size":"2em"},2500);
		$(".capa-animable2").animate({top:-100},"slow");
		$(".capa-animable2").animate({
			left:0,
			top:0,
			"font-size":"1em",
			width:100
		},5000);
	});

	$("#boton12").on("click", function(){
		//$(".parrafo-oculto").hide(2000);
		//alert("El párrafo esta oculto");

		//función tipo callback
		$(".parrafo-oculto").hide(2000,function(){
			alert("El párrafo esta oculto");
		});
	});

	$("#boton13").on("click",function(){
		$("p").html("<i>El contenido ha sido cambiado</i><input type='text'/>");
	});

	$("#boton14").on("click",function(){
		$("p").prepend("<b>contenido agregado antes</b><img src='http://bextlan.com/img/bextlan.png' />");
	});

	$("#boton15").on("click",function(){
		$("p").append(" <b>contenido agregado después</b><img src='http://bextlan.com/img/bextlan.png' />");
	});

	$("#boton16").on("click",function(){
		$("p").before("<div class='antes'><i>contenido agregado antes de p</i></div>");
		$(".antes").css("background","magenta");
	});

	$("#boton17").on("click",function(){
		$("p").after("<div class='despues'><i>contenido agregado después de p</i></div>");
		$(".despues").css("background","cyan");
	});

	$("#boton18").on("click",function(){
		$("p").css("background-color","peru");
	});

	$("#boton19").on("click",function(){
		$("p").css({
			"background-color":"#EEE",
			border:"thick solid green",
			borderRadius:"1em",
			fontSize:"2em",
			padding:"1em",
			"text-shadow":"5px 5px 10px #000"
		});
	});

	$("a").on("click",function(enlace){
		enlace.preventDefault();
		alert("he prevenido la acción predeterminada");
	});

	$("a").on("mouseover",function(){
		$("span").addClass("span-css");
	});

	$("a").on("mouseout",function(){
		$("span").removeClass("span-css");
	});

	$("#boton20").on("click",function(){
		$("#ajax").load("otra-pagina.html");
	});

	$("#boton21").on("click",function(){
		$("#ajax").load("otra-pagina.html",function(){
			$(this).fadeOut(2000).fadeIn(2000);
		});
	});

	$(document).on("keydown",muevete);

	$("#cual-tecla").on("keyup",function(tecla){
		$("#codigo-tecla").text(tecla.target.value+": "+tecla.which);
	});

	$(window).on("resize",esMovil);
	
	$(window).on("scroll",detectarScroll);

	$("button").on("click",function(){
		$("body,html").animate({
			scrollTop:0
		},1000);
	});
}//cierra la función efectos

function detectarScroll()
{
	/*if($(window).scrollTop()>100)
	{
		$("button").fadeIn();
	}
	else
	{
		$("button").fadeOut();
	}*/

	return ($(window).scrollTop()>100)?$("button").fadeIn():$("button").fadeOut();
}

function esMovil()
{
	var movil = ($(window).width()<800)?true:false;
	console.log(movil,$(window).width());

	if(movil)
	{
		$("body,html").css({
			background:"black",
			color:"white"
		});
	}
	else
	{
		$("body,html").css({
			background:"gray",
			color:"navy"
		});
	}

}

function muevete(tecla)
{
	//alert("detección de teclado: "+tecla.keyCode);
	switch(tecla.keyCode)
	{
		case 37:
			tecla.preventDefault();
			$("#pacman").animate({left:"-=2em"},"swing");
			break;

		case 38:
			tecla.preventDefault();
			$("#pacman").animate({top:"-=2em"},"swing");
			break;

		case 39:
			tecla.preventDefault();
			$("#pacman").animate({left:"+=2em"},"swing");
			break;

		case 40:
			tecla.preventDefault();
			$("#pacman").animate({top:"+=2em"},"swing");
			break;
	}
}

$(document).on("ready",efectos);
/*
http://librojquery.com/
http://www.oscarotero.com/jquery/
*/