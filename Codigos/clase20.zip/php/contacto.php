<?php 
//echo "Los datos han pasado por PHP con ayuda de $.ajax =D";

$nombre = $_POST["nombre_txt"];
$email = $_POST["email_txt"];
$cumple = $_POST["cumple_txt"];
$asunto = $_POST["asunto_txt"];
$comentarios = $_POST["comentarios_txa"];

/*echo "Los datos que enviaste son:<br />";
echo "Nombre: ".$nombre."<br />";
echo "Email: ".$email."<br />";
echo "Cumple: ".$cumple."<br />";
echo "Asunto: ".$asunto."<br />";
echo "Comentarios: ".$comentarios."<br />";*/

$de="jonmircha@bextlan.com";
$para=$email;
$mensaje = "<p>".$nombre.", te ha enviado el siguiente mensaje:</p><p>".$comentarios.".</p><p>Su fecha de nacimiento es: ".$cumple.".</p>";
$cabeceras = "MIME-Version: 1.0\r\n";
$cabeceras .= "Content-type: text/html; charset=iso-8859-1\r\n";
$cabeceras .= "From: $de \r\n";

$respuesta = (mail($para,$asunto,$mensaje,$cabeceras))?"Los Datos han sido enviados.":"Ocurrio un error. Los datos no se enviaron.";
echo $respuesta;
//http://cursos.bextlan.com/frontend/formulario/contacto.html
?>