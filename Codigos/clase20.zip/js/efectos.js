//carga de contenido común función que se ejecuta en todas mis secciones
function cargarContenidoComun()
{
	$("header").load("html/header.html");
	$("footer").load("html/footer.html");
	$("#contenido").css({display:"none"}).fadeIn("slow");
	$("header").before("<input type='checkbox' id='menu-movil' /><label for='menu-movil'></label>");
}

//código para index.html
function iniciarSlider()
{
	cargarContenidoComun();

	$("#slider").flexslider({
		animation:"slide",
		/*direction:"vertical",*/
		controlNav:false
	});

	if($(window).width()<=600)
	{
		$("#social-media").remove();
	}
}

//código para contacto.html
/*
test: es la evaluación para saber si tenemos soporte en el navegador
yep: se indican las librerías que se cargan en caso verdadero
nope: se indican las librerías que se cargan en caso falso
complete: se indica que debe realizarse después de cargar las librerías
*/
var calendario = {
	test:Modernizr.inputtypes.date,
	yep:enviarDatos,
	nope:[
		"http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css",
		"http://code.jquery.com/jquery-1.9.1.js",
		"http://code.jquery.com/ui/1.10.3/jquery-ui.js"
	],
	complete:function(){
		$("input[type=date]").datepicker({
			dateFormat:"dd/mm/yy"
		});
	}
};

function enviarDatos(evento)
{
	//alert("yep");
	evento.preventDefault();

	var datosFormulario = $(this).serialize();
	console.log(datosFormulario);

	var opcionesDeEnvio = {
		url:"php/contacto.php",
		type:"POST",//POST o GET
		data:datosFormulario,
		dataType:"text", /*json,xml,html,text,script*/
		beforeSend:function(){
			//alert("Antes de enviar");
			$("#precarga").fadeIn("slow");
		},
		error:function(){
			//alert("Ocurrió un error");
			$("#precarga").fadeOut("slow");
			$("#respuesta").addClass("mensaje").fadeIn("slow").html("Ocurrió un error. No se pudo conectar con el servidor.");
		},
		success:function(respuestaDePHP){
			//alert("El envío por AJAX fue exitoso");
			$("#precarga").fadeOut("slow");
			$("#respuesta").addClass("mensaje").fadeIn("slow").html(respuestaDePHP);
			$("#contacto")[0].reset();
		}
	};

	$.ajax(opcionesDeEnvio);
}

function contacto()
{
	cargarContenidoComun();

	if($(window).width()<=480)
	{
		$("#mapa").remove();
	}
}