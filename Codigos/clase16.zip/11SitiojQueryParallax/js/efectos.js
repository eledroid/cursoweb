function efectos()
{
	//alert("funciona");
	$("#uno").on("click",function(enlace){
		enlace.preventDefault();
		$("#contenido").load("html/seccion1.html",function(){
			$(this).fadeOut().fadeIn();
		});
	});

	$("#dos").on("click",function(enlace){
		enlace.preventDefault();
		$("#contenido").load("html/seccion2.html",function(){
			$(this).css({display:"none"}).fadeIn(2000);
		});
	});

	$("#tres").on("click",function(enlace){
		enlace.preventDefault();
		$("#contenido").load("html/seccion3.html",function(){
			$(this).css({display:"none"}).slideDown(2000);
		});
	});

	$("#cuatro").on("click",function(enlace){
		enlace.preventDefault();
		$("#contenido").load("html/seccion4.html",function(){
			$(this).css({display:"none"}).show(2000);
		});
	});
}

$(document).on("ready",efectos);