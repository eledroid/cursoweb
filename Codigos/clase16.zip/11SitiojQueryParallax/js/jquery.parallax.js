$(document).on("ready",function(){
	$("a.parallax").parallax({
		velocidad:2000
	});
});

(function($){
	jQuery.fn.extend({
		parallax:function(opciones)
		{
			iniciales = {
				velocidad:1000
			}

			var opciones = $.extend({},iniciales,opciones);

			function inicializar()
			{
				//LIBRERIAS

				//VARIABLES

				//FUNCIONES
				function aDondeVoy()
				{
					var idEnlace = $(this).attr("href");
					console.log("Id Enlace:",idEnlace);
					
					//offset() me da las coordenadas top left de mi elemento
					var destinoPagina = $(idEnlace).offset().top;
					console.log("Destino de la Página:",destinoPagina);

					$("body, html").animate({
						scrollTop:destinoPagina
					},opciones.velocidad);
				}

				//EVENTOS y ESTADOS INICIALES
				$(this).on("click",aDondeVoy);
			}

			return $(this).each(inicializar);
		}
	});
})(jQuery);